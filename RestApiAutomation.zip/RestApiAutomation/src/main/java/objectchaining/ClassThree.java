package objectchaining;

public class ClassThree {
	public static void methodThree(){
		System.out.println("methodThree");
	}
}
